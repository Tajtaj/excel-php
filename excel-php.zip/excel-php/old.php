<?php
require_once 'parseCSV.php';
$csvParse = new parseCSV();
//$csvParse->auto("analyzing.csv");
$csvParse->auto("classifier-adjusted-reality_2_0.csv");
$rowhead = "";
echo "<table>";
echo "<thead><tr>";
foreach ($csvParse->data as $key => $row) {
  foreach($row as $head => $val){
  	echo "<th>".$head."</th>";
  }
  break;
}
echo "</tr></thead>";
echo "<tbody>";
foreach ($csvParse->data as $key1 => $row1) {
  $rowhead .= "<tr>";
  foreach($row1 as $head1 => $val1){
  	$rowhead .= "<td>".$val1."</td>";
  }
  $rowhead .= "</tr>";
}
echo $rowhead;
echo "</tbody>";
echo "</table>";

?>